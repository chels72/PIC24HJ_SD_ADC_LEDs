#include "mcc_generated_files/system.h"

#define FOSC (20000000ULL)
#define FCY (FOSC/2)

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <xc.h>

#include "OLED/OLED.h"
#include <libpic30.h>
#include <string.h>
#include "mcc_generated_files/fatfs/ff.h"
#include "mcc_generated_files/sd_spi/sd_spi.h"
#include "mcc_generated_files/system.h"

void OLED_Readout(char *str);
void OLED_Readout2(char *str);
void checkSDReturn(FRESULT result);
char str [32];
 
//for adc
int ADCValue = 0;
int ADCValue2 = 0;
double avalue = 0.0; //analog value for adc
double avalue2 = 0.0; //analog value for adc
void configADC(void);
void getADC(void);
 //for sd         
FATFS fs;           /* Filesystem object */
FIL fil;            /* File object */
FRESULT res;        /* API result code */
BYTE work[FF_MAX_SS]; /* Work area (larger is better for processing time) */
 char adc[32];
void fileSetup(void);
void fileClose(void);

//for led driver 4hz clock
void LED_clock(void);

int main(void)
{
    /*
     CODE TOGGLES PIN 15 FOR "50MS" THEN PIN 16, ACTING AS CLOCK FOR LED DRIVER SLOWER SIGNALS
     SAMPLES ADC CH1 SET NUMBER OF TIMES, SAVES TO FILE
     REPEAT FOR ADC CH2 
     */
    
    
    SYSTEM_Initialize();   
    
    OLED_Readout("BEGIN90");

   LED_clock();//2 clock 4hz led driver
   
    configADC(); //adc settings

    fileSetup(); //mount and open file, prepare for adc
    
    getADC(); //get adc value from ch1 and 2    
    
    OLED_Readout("Wrote file!");
        
    fileClose(); //closes and unmounts sd

 OLED_Readout("All done !");
 
 __delay_ms(50);
   
    return 0;
}

//print string with .5 second delay
void OLED_Readout(char *str)
{
    OLED_ClearDisplay();
    OLED_Write_Text(0,0,str);
    OLED_Update();
    __delay_ms(500);
}
void OLED_Readout2(char *str)
{
    OLED_ClearDisplay();
    OLED_Write_Text(0,8,str);
    OLED_Update();
    __delay_ms(500);
}

void checkSDReturn(FRESULT result)
{
    switch(result){
        case FR_DISK_ERR:
            OLED_Readout2("FR_DISK_ERR");
            break;
            
        case FR_INT_ERR:
            OLED_Readout2("FR_INT_ERR");
            break;
            
        case FR_NOT_READY:
            OLED_Readout2("FR_NOT_READY");
            break;
        
        case FR_NO_FILE:
            OLED_Readout2("FR_NO_FILE");
            break;
        
        case FR_NO_PATH:
            OLED_Readout2("FR_NO_PATH");
            break;
            
        case FR_INVALID_NAME:
            OLED_Readout2("FR_INVALID_NAME");
            break;
            
        case FR_DENIED:
            OLED_Readout2("FR_DENIED");
            break;
            
        case FR_EXIST:
            OLED_Readout2("FR_EXIST");
            break;
            
        case FR_INVALID_OBJECT:
            OLED_Readout2("FR_INVALID_OBJECT");
            break;
            
        case FR_WRITE_PROTECTED:
            OLED_Readout2("FR_WRITE_PROTECTED");
            break;
            
        case FR_INVALID_DRIVE:
            OLED_Readout2("FR_INVALID_DRIVE");
            break;
            
        case FR_NOT_ENABLED:
            OLED_Readout2("FR_NOT_ENABLED");
            break;
            
        case FR_NO_FILESYSTEM:
            OLED_Readout2("FR_NO_FILESYSTEM");
            break;
            
        case FR_MKFS_ABORTED:
            OLED_Readout2("FR_MKFS_ABORTED");
            break;
            
        default:
            OLED_Readout2("Dunno");
            break;
    }
}


void configADC(void){
     _TRISA1 = 1; //sets pin to input AN1
        _PCFG1 = 0; //0 = Port pin in Analog mode, port read input disabled, ADC samples pin voltage
           _TRISA0 = 1; //sets pin to input AN0
        _PCFG0 = 0; //0 = Port pin in Analog mode, port read input disabled, ADC samples pin voltage
        
    //register ad1con1
    _ADON = 0; //ADC IS OFF, LEAVE THIS NOT TO MESS UP SETTING UP
    //ADSIDL FOR IDLE MODE
    _AD12B = 0 ; // SETS 12 BIT, 1 CH, 0 IS 10 BIT 4CH CHANGE SIMSAM TOO
    _FORM = 0; //POSITIVE INTEGER
    _SSRC = 7; //BINARY 111
    _ASAM = 1; // AUTOSETS SAMPLINGS
    _SIMSAM = 1; // SAMPLES CHS SIMULATANEOUSLY
            
    //REGISTER AD1CON2
    _VCFG = 000; //SETS VOLT REF
    //_CSCNA SCANS CHANNELS
    _CHPS = 01; //SETS CH0 AND CH1
    //BUFS MAKE BUFFER FASTER
    _SMPI = 0;
    //_BUFM START FILLING BUFFER
    
    //REGISTER AD1CON3
    _ADRC = 1; //INTERNAL RC CLOCK
    
    //ACTIVATE AD1CHS123 WHEN USING MORE THAN 1 CH
    //register AD1CHS123
    _CH123SB = 0; //SETS AN0, AN1, AND AN2 AS POS CH
    
    
    //REGISTER AD1CHS
    _CH0NA = 0;//NEG REF IS VREF-
    //_CH0SA = 00000; // POS IS AN0
    //_CH0SA1 = 00001;
  
    
   
            
    //REGISTER INTCON1
    _NSTDIS = 0 ; //DISABLE INTERRUPT OVERLAP
    
    //REGISTER INTERUPT FLAG 
    _AD1IF = 0;//CONVERSION STATUS FOR ADC, 0 CLEARS THE FLAG
   _AD1IE = 1; //CONVERSION
   //IPC
   _AD1IP = 0 ;//PRIORITY FOR ADC INTERRUPTS, 7 HIGH, 0 OFF
   
  //   _ADON = 1 ;//TURNS ADC ON
}


void LED_clock(void)
{
      int z;
        for (z=0; z<1; z++)
    {
            OLED_Readout("LED Start");
            
        int x=0;
        for (x; x<30; x++)
        {
        LATBbits.LATB6 = 1;
        __delay_ms(50);
        LATBbits.LATB6 = 0;
        __delay_ms(50);
        }
      
        
        int y=0;
        for (y; y<30; y++)
        {
        LATBbits.LATB7 = 1;
        __delay_ms(50);
        LATBbits.LATB7 = 0;
        __delay_ms(50);
        }
        
        OLED_Readout("Done with LED Driver");
        __delay_ms(50);
    }
}


void getADC(void){
    int x;
for (x=0; x<4; x++)
{
   OLED_Readout("AN0");
   
    _CH0SA = 0; //NEED FOR THE ADC CHANNEL 
        
    _ADON = 1; // turn ADC ON
 
   __delay_ms(100); // sample for 100 mS
   
    AD1CON1bits.SAMP = 0; // start Converting

    if (AD1CON1bits.DONE = 1)
    {
    ADCValue = ADC1BUF0; // yes then get ADC value
    AD1CON1bits.DONE = 0; //CLEAR FLAG
    }

    avalue= (ADCValue * 3.3) / 1024; //will give actual volatage value
    char str[32];
       //display adc value
        OLED_ClearDisplay();
        sprintf(str, "Analog is %f", (double)avalue );
        OLED_Write_Text(0,0,str);
        OLED_Update();
        __delay_ms(200);
        
     
        sprintf(adc, "avalue is %f\n", avalue);
        f_puts(adc, &fil);

        
}
    int y;
for (y=0; y<4; y++)
{
        OLED_Readout ("AN1");
        
        _ADON = 0; 
      _CH0SA = 1; //NEED TO CHANGE FROM AN0 TO AN1
     
        _ADON = 1; // turn ADC ON
 
   __delay_ms(100); // sample for 100 mS
   
    AD1CON1bits.SAMP = 0; // start Converting
    
  // while (!AD1CON1bits.DONE);// conversion done?
    if (AD1CON1bits.DONE = 1)
    {
        
    ADCValue2 = ADCBUF0; // yes then get ADC value
    AD1CON1bits.DONE = 0; //CLEAR FLAG 
    }

    avalue2= (ADCValue2 * 3.3) / 1024; //will give actual volatage value
    
    //display adc value
        OLED_ClearDisplay();
        sprintf(str, "Analog is %f", (double)avalue2 );
        OLED_Write_Text(0,0,str);
        OLED_Update();
        __delay_ms(200);

        sprintf(adc, "avalue2 is %f\n", avalue2);
        f_puts(adc, &fil);

}
}


void fileSetup(void){
    res = f_mount(&fs, "", 1);
            while(res != FR_OK)//do not continue
            {OLED_Readout("Mount failed!");
                checkSDReturn(res); }
            OLED_Readout("Mounted SD!");
    
    res = f_open(&fil, "loop.txt", FA_CREATE_ALWAYS | FA_WRITE);
        while(res != FR_OK)//do not continue
        { OLED_Readout("File not open!");
            checkSDReturn(res); }
        OLED_Readout("Open file!");
}


void fileClose(void){
    res = f_close(&fil);
        while(res != FR_OK)//do not continue
        {OLED_Readout("File not closed!");
            checkSDReturn(res);}
    
    res = f_mount(0,"",0); //unmount disk
        while(res != FR_OK)//do not continue
        { OLED_Readout("Unmount fail!");
            checkSDReturn(res); }
}