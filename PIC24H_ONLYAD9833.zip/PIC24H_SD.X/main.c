//******************************************************************************
//                                                                            *
//                START OF CODE
// BULT BY UCF 2020-2022 Team members include
// Chelsea Kincaid     - Clutch late game programming
// Nick Sally          - Resident Electrical ENgineer
// Abbey Havel         - Optics
// Giovanni Wancelotti - Early programming
// Zach Rogers         - Thermal        
// Andrew Derusha      - 1337 3d printed components      
// Hamil Patel         - 3d printed structures
// Anthony Terracciano - The Master
// Tech lead
// PI: Subith S. Vasu        
//                                                                            
//******************************************************************************




//******************************************************************************
//       SSSSSSS    YY      YY      SSSSSSS
//      SSS          YY    YY      SSS    
//      SS            YY  YY       SS              
//       SSSSSS        YYYY         SSSSSS        
//            SS        YY               SS        
//           SSS        YY              SSS        
//      SSSSSSS         YY         SSSSSSS        
//******************************************************************************

// 7/18/2022 start address = 0x0, end address = 0xa8ff

#define NUMSAMPLES 1000 //sets how many adc samples are taken for the average

#define FOSC (20000000ULL)
#define FCY (FOSC/2)

#define AD9833_SPI_ChipSelect()     (_LATB14 = 0) // CS pin for function gen
#define AD9833_SPI_ChipDeselect()   (_LATB14 = 1)


#include <stdio.h> //main headers for syntax, compiler
#include <stdlib.h>
#include <stdbool.h>
#include <xc.h>
#include <libpic30.h>
#include <string.h>


#include "mcc_generated_files/system.h"

#include "mcc_generated_files/fatfs/ff.h" //for sd formatting
#include "mcc_generated_files/sd_spi/sd_spi.h" //sd 
#include "mcc_generated_files/spi1_driver.h" //sd
#include "mcc_generated_files/spi1_types.h" //sd

#include "mcc_generated_files/sd_spi/../spi2_driver.h" //ad9833
#include "mcc_generated_files/sd_spi/../spi2_types.h" //ad9833

#include "bmp280.h" //temp press sensor
#include "DS3231.h" //rtc

//for LCD screen
#include "OLED/OLED.h" //for debugging LCD screen
void OLED_Readout(char *str); 
void OLED_Readout2(char *str);
void checkSDReturn(FRESULT result);
char str [32];
 
//for adc

void configADC(void); //sets registers
float getADC1(void); //reads, converts analog pins; saves to avalue variable
float getADC2(void);
int ADCValue = 0; //what is read on pin, analog value
int ADCValue2 = 0;
double avalue = 0.0; //final  avg value for adc
double avalue2 = 0.0; //final avg value for adc
float sum=0; //used for sum of adc before avg
float sum2=0;


 //for sd file saving         
FATFS fs;           /* Filesystem object */
FIL fil;            /* File object */
FRESULT res;        // API result code, for debugging
char adc[32]; //need for saving file
void fileSetup(void); //mount and opens file
void fileClose(void); //unmount and close
void writeFile (double avalue, double avalue2, double temp, double press); //write data, gets time
void writeHeader(void); //header for data

//for led driver clocks
void LEDA_clock(void); //pin b6, turns on and off
void LEDB_clock(void); //pin b7
void AD9833start(void); //turns on 
void AD9833stop(void); //not sure if this works
    int p;

    void checkP(int p);
    void checkP2(int p);
//fro temperature and pressure
double temp;
double press;
double  getTemp (void); //uses bmp280, saves to variable temp
double  getPress (void); //uses bmp280, saves to variable press


//*****************************************************************************
//        MM	     MM  	  AAAA       IIIIII  NN	   NN                     *         
//        MMMM	   MMMM      AA  AA		   II    NNNN  NN                     *        
//        MM MM   MM MM     AA    AA       II    NN NN NN                     *        
//        MM  MM MM  MM    AAAAAAAAAA      II    NN  NNNN                     *        
//        MM   MMM   MM   AA		AA	   II    NN   NNN                     *        
//        MM         MM  AA		     AA  IIIIII  NN	   NN                     *    
//*****************************************************************************



int main(void)
{
    /*
     Turns on, starts AD9833 at "600mV 1Mhz sin wave", LED A "4Hz" clock for ".3 seconds" on and off, 
     *  LED B "4Hz" clock for ".3 seconds" on and off, ADC samples channel 1 then channel 2, 
     * gets temperature and pressure, turns off AD9833, writes file 
     */
//general configuration only ran at beginning
SYSTEM_Initialize();   
configADC(); //adc settings   


//OLED_Readout("BEGIN5");

//set up csv header, lets you know when microcontroller is restarted
fileSetup();
writeHeader();
fileClose();


int x;
for(x=0; x<10;x++)
{
//  AD9833start(); 

//loop for adc1 sampling        
LEDA_clock(); //starts the 4hz which continues on gget adc1())
getADC1(); //get adc value from ch1 and 2, also outputs the 4hz led clock
avalue= (sum * 3.3) / (1024 * NUMSAMPLES); //will give actual volatage value average
sum=0; //reset variable for next loop

 /*    OLED_ClearDisplay();
        sprintf(str, "ADC1 %.5f", avalue);
        OLED_Write_Text(0,0,str);
        OLED_Update();
  */

//loop for adc2 sampling
LEDB_clock();
getADC2();      
avalue2= (sum2 * 3.3) / (1024 * NUMSAMPLES); //will give actual volatage value
sum2=0;
  /*
     OLED_ClearDisplay();
        sprintf(str, "ADC2 %.5f", avalue2);
        OLED_Write_Text(0,8,str);
        OLED_Update();
   * */


//AD9833stop();
OLED_Readout("ADC DONE!"); 
  
//get other data  
getTemp(); //bmp280
getPress();



//save data
fileSetup(); //mount and open file
writeFile (avalue, avalue2, temp, press); //saves all those variale to file, gets time and date
fileClose(); //closes and unmounts sd 

//}//end of main loop 

}

OLED_Readout("All done !");
return 0;
}


//*****************************************************************************
//		 CCCCCC		  AAAA        NN	NN          FFFFFF    NN    NN        *
//		CCCCC        AA	 AA		  NNNN	NN          FF		  NNNN  NN        *
//		CC	        AA 	  AA      NN NN NN          FFFF	  NN NN NN        *
//	 	CC	   	   AAAAAAAAAA     NN  NNNN          FF		  NN  NNNN        *
//		CCCCC  	  AA		AA	  NN   NNN          FF		  NN   NNN        *
//		 CCCCCC  AA			 AA   NN	NN          FF		  NN	NN        *
//*****************************************************************************


//print string with .5 second delay
void OLED_Readout(char *str)
{
    OLED_ClearDisplay();
    OLED_Write_Text(0,0,str);
    OLED_Update();
    __delay_ms(500);
}
void OLED_Readout2(char *str)
{
    OLED_ClearDisplay();
    OLED_Write_Text(0,8,str);
    OLED_Update();
    __delay_ms(500);
}

void checkSDReturn(FRESULT result)
{
    switch(result){
        case FR_DISK_ERR:
            OLED_Readout2("FR_DISK_ERR");
            break;
            
        case FR_INT_ERR:
            OLED_Readout2("FR_INT_ERR");
            break;
            
        case FR_NOT_READY:
            OLED_Readout2("FR_NOT_READY");
            break;
        
        case FR_NO_FILE:
            OLED_Readout2("FR_NO_FILE");
            break;
        
        case FR_NO_PATH:
            OLED_Readout2("FR_NO_PATH");
            break;
            
        case FR_INVALID_NAME:
            OLED_Readout2("FR_INVALID_NAME");
            break;
            
        case FR_DENIED:
            OLED_Readout2("FR_DENIED");
            break;
            
        case FR_EXIST:
            OLED_Readout2("FR_EXIST");
            break;
            
        case FR_INVALID_OBJECT:
            OLED_Readout2("FR_INVALID_OBJECT");
            break;
            
        case FR_WRITE_PROTECTED:
            OLED_Readout2("FR_WRITE_PROTECTED");
            break;
            
        case FR_INVALID_DRIVE:
            OLED_Readout2("FR_INVALID_DRIVE");
            break;
            
        case FR_NOT_ENABLED:
            OLED_Readout2("FR_NOT_ENABLED");
            break;
            
        case FR_NO_FILESYSTEM:
            OLED_Readout2("FR_NO_FILESYSTEM");
            break;
            
        case FR_MKFS_ABORTED:
            OLED_Readout2("FR_MKFS_ABORTED");
            break;
            
        default:
            OLED_Readout2("Dunno");
            break;
    }
}


void configADC(void){
     _TRISA1 = 1; //sets pin to input AN1
        _PCFG1 = 0; //0 = Port pin in Analog mode, port read input disabled, ADC samples pin voltage
           _TRISA0 = 1; //sets pin to input AN0
        _PCFG0 = 0; //0 = Port pin in Analog mode, port read input disabled, ADC samples pin voltage
        
    //register ad1con1
    _ADON = 0; //ADC IS OFF, LEAVE THIS NOT TO MESS UP SETTING UP
    //ADSIDL FOR IDLE MODE
    _AD12B = 0 ; // SETS 12 BIT, 1 CH, 0 IS 10 BIT 4CH CHANGE SIMSAM TOO
    _FORM = 0; //POSITIVE INTEGER
    _SSRC = 0; //BINARY 111 IS 7
    _ASAM = 0; // AUTOSETS SAMPLINGS
    _SIMSAM = 0; // SAMPLES CHS SIMULATANEOUSLY if 1
            
    //REGISTER AD1CON2
    _VCFG = 000; //SETS VOLT REF
    //_CSCNA SCANS CHANNELS
    _CHPS = 01; //SETS CH0 AND CH1
    //BUFS MAKE BUFFER FASTER
    _SMPI = 0;
    //_BUFM START FILLING BUFFER
    
    //REGISTER AD1CON3
    _ADRC = 1; //INTERNAL RC CLOCK
    
    //ACTIVATE AD1CHS123 WHEN USING MORE THAN 1 CH
    //register AD1CHS123
    _CH123SB = 0; //SETS AN0, AN1, AND AN2 AS POS CH
    
    _CH0NB= 0;
    _CH0SB =1;
    //REGISTER AD1CHS
    _CH0NA = 0;//NEG REF IS VREF-
    //_CH0SA = 00000; // POS IS AN0
    //_CH0SA1 = 00001;
  
    
   
            
    //REGISTER INTCON1
    _NSTDIS = 0 ; //DISABLE INTERRUPT OVERLAP
    
    //REGISTER INTERUPT FLAG 
   // _AD1IF = 0;//CONVERSION STATUS FOR ADC, 0 CLEARS THE FLAG
  // _AD1IE = 1; //CONVERSION
   //IPC
//   _AD1IP = 0 ;//PRIORITY FOR ADC INTERRUPTS, 7 HIGH, 0 OFF
   
  //   _ADON = 1 ;//TURNS ADC ON
   

AD1CON3bits.ADRC = 0; // ADC Clock is derived from Systems Clock
AD1CON3bits.SAMC = 0; // Auto Sample Time = 0 * TAD
AD1CON3bits.ADCS = 2; // ADC Conversion Clock TAD = TCY * (ADCS + 1) = (1/40M) * 3 =
 // 75 ns (13.3 MHz)
 // ADC Conversion Time for 10-bit Tconv = 12 * TAD = 900 ns (1.1 MHz)
AD1CON1bits.ADDMABM = 1; // DMA buffers are built in conversion order mode

IFS0bits.AD1IF = 0; // Clear the Analog-to-Digital interrupt flag bit
IEC0bits.AD1IE = 0; // Do Not Enable Analog-to-Digital interrupt

}


void LEDA_clock(void)
{

    int x=0;
    for (x; x<5; x++)
    {
    LATBbits.LATB6 = 0;
    __delay_ms(125);
    LATBbits.LATB6 = 1;
    __delay_ms(125);
    }


}

void LEDB_clock(void){
   int y=0;
  for (y; y<5; y++)
    {
    LATBbits.LATB7 = 0;
    __delay_ms(125);
    LATBbits.LATB7 = 1;
    __delay_ms(125);
    } 

}

float getADC1(void)
{


   _ADON=0;
    _CH0SA = 0; //NEED FOR THE ADC CHANNEL 
        
    _ADON = 1; // turn ADC ON
    int y;
for (y=0; y<NUMSAMPLES; y++)
{
    //have led 4hz 
    p++;

    
    if (p == 1)  
        {LATBbits.LATB6 = 0;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
        }
    else if (p == 125)  
        {LATBbits.LATB6 = 1;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
        }
    
    else if (p == 250)  
        {LATBbits.LATB6 = 0;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
        }
    
    if (p == 375)  
        {LATBbits.LATB6 = 1;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
        }
    
    else if (p ==500)
        {  LATBbits.LATB6 = 0;
        _SAMP=1;
      __delay_ms(1); // sample for __ mS

       AD1CON1bits.SAMP = 0; // start Converting

      // if (AD1CON1bits.DONE = 1)
       while (!AD1CON1bits.DONE);
       {
       ADCValue = ADC1BUF0; // yes then get ADC value
       AD1CON1bits.DONE = 0; //CLEAR FLAG
       }


       sum += ADCValue;

      }
    
    else if (p ==625)  
        {  LATBbits.LATB6 = 1;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
        }
    
    else if (p == 750)  
        {LATBbits.LATB6 = 0;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
        }
    
    else  if (p == 875)  
        {LATBbits.LATB6 = 1;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
        }
    
    else   if (p == 999)  
        {LATBbits.LATB6 = 0;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
     }
    
    else
        {
      _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;

         }


} 
    p=0;
        return sum;
        

    
}

float getADC2(void){

        
        _ADON = 0; 
      _CH0SA = 1; //NEED TO CHANGE FROM AN0 TO AN1
     
        _ADON = 1; // turn ADC ON
        int u;
for (u=0; u<NUMSAMPLES; u++)
      {
    p++;
  //  checkP2(p);
            
    if (p == 1)  
        {LATBbits.LATB7 = 0;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
        }
    else if (p == 125)  
        {LATBbits.LATB7 = 1;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
        }
    
    else if (p == 250)  
        {LATBbits.LATB7 = 0;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
        }
    
    if (p == 375)  
        {LATBbits.LATB7 = 1;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
        }
    
    else if (p ==500)
        {  LATBbits.LATB7 = 0;
        _SAMP=1;
      __delay_ms(1); // sample for __ mS

       AD1CON1bits.SAMP = 0; // start Converting

      // if (AD1CON1bits.DONE = 1)
       while (!AD1CON1bits.DONE);
       {
       ADCValue = ADC1BUF0; // yes then get ADC value
       AD1CON1bits.DONE = 0; //CLEAR FLAG
       }


       sum += ADCValue;

      }
    
    else if (p ==625)  
        {  LATBbits.LATB7 = 1;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
        }
    
    else if (p == 750)  
        {LATBbits.LATB7 = 0;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
        }
    
    else  if (p == 875)  
        {LATBbits.LATB7 = 1;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
        }
    
    else   if (p == 999)  
        {LATBbits.LATB7 = 0;
          _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;
     }
    
    else
        {
      _SAMP=1;
       __delay_ms(1); // sample for __ mS

        AD1CON1bits.SAMP = 0; // start Converting

       // if (AD1CON1bits.DONE = 1)
        while (!AD1CON1bits.DONE);
        {
        ADCValue = ADC1BUF0; // yes then get ADC value
        AD1CON1bits.DONE = 0; //CLEAR FLAG
        }


        sum += ADCValue;

         }
}
        p=0;
        return sum2;

}
 
void fileSetup(void){
    
 
    res = f_mount(&fs, "", 1);
            while(res != FR_OK)//do not continue
          {OLED_Readout("Mount failed!");
                checkSDReturn(res); }
          //  OLED_Readout("Mounted SD!");
   
    res = f_open(&fil, "loop.txt", FA_OPEN_APPEND | FA_WRITE);
      while(res != FR_OK)//do not continue
        { OLED_Readout("File not open!");
            checkSDReturn(res); }
     //   OLED_Readout("Open file!");
     
}


void fileClose(void){
    res = f_close(&fil);
        while(res != FR_OK)//do not continue
        {OLED_Readout("File not closed!");
            checkSDReturn(res);}
    
    res = f_mount(0,"",0); //unmount disk
        while(res != FR_OK)//do not continue
        { OLED_Readout("Unmount fail!");
            checkSDReturn(res); }
}


void AD9833start(void)
{
    //spi2_open(SPI2_DEFAULT);
    if(spi2_open(SPI2_DEFAULT) == false)
        OLED_Readout("AD9833 not ready");
    
    //Commands & Registers
    uint8_t CONTROL[2]  = {0x20, 0x62};
    uint8_t RESET[2]    = {0x21, 0x62};
    uint8_t FREQ_MSB[2] = {0x40, 0xC9};
    uint8_t FREQ_LSB[2] = {0x74, 0x75};
    
    AD9833_SPI_ChipSelect();
    spi2_writeBlock(RESET, 2);
    spi2_writeBlock(FREQ_MSB, 2);
    spi2_writeBlock(FREQ_LSB, 2);
    spi2_writeBlock(CONTROL, 2);
   // AD9833_SPI_ChipDeselect();
    
   OLED_Readout("AD9833 running"); return;
}

void AD9833stop(void){
    AD9833_SPI_ChipDeselect();
    //spi2_close();
     
      OLED_Readout ("AD9833 off");
      return;
}

double  getTemp(void){

    
        temp = BMP280_ReadTemperature();
       
        
        return temp; //to save on sd
    
}

double  getPress(void){
    press = BMP280_ReadPressure();
    
        
    return press; //to save on sd
}

void writeHeader(void){
    
    //make csv header
          sprintf(adc, "Date (#:MM:DD:YY)");
        f_puts(adc, &fil);
        
        sprintf( adc, ",");
        f_puts(adc, &fil); 
    
      sprintf(adc, "Time (HH:MM:SS)");
        f_puts(adc, &fil);
        
        sprintf( adc, ",");
        f_puts(adc, &fil); 
        
          sprintf(adc, "ADC1 (V)");
        f_puts(adc, &fil);
        
        sprintf( adc, ",");
        f_puts(adc, &fil); 
        
          sprintf(adc, "ADC2 (V)");
        f_puts(adc, &fil);
        
        sprintf( adc, ",");
        f_puts(adc, &fil); 
        
          sprintf(adc, "Temp (C)");
        f_puts(adc, &fil);
        
        sprintf( adc, ",");
        f_puts(adc, &fil); 
        
          sprintf(adc, "Press (mTorr)\r");
        f_puts(adc, &fil);

}

void writeFile (double avalue, double  avalue2, double  temp, double  press)
{
   //csv
    
           Generate_Datestamp(str);
             sprintf(adc, "%s", str);
        f_puts(str, &fil);
        
      sprintf( adc, ",");
        f_puts(adc, &fil); 
        
    DS3231_RefreshTime();
        Generate_Timestamp(str);

      sprintf(adc, "%s", str);
        f_puts(str, &fil);
        
      sprintf( adc, ",");
        f_puts(adc, &fil); 
        

        
            sprintf(adc, "%.3f", avalue);
        f_puts(adc, &fil);
        
          sprintf(adc,",");
        f_puts(adc, &fil);
        
               sprintf(adc, "%.3f", avalue2);
        f_puts(adc, &fil);
        
          sprintf( adc, ",");
        f_puts(adc, &fil);
        
               sprintf(adc, "%.3f", temp);
        f_puts(adc, &fil);
        
          sprintf( adc, ",");
        f_puts(adc, &fil);
        
               sprintf(adc, "%.3f\r", press);
        f_puts(adc, &fil);

}





//*****************************************************************************
//					EEEEEEE 	NN    NN	DDDDDD                            *
//					EE      	NNNN  NN	DD   DD                           *
//					EEEE    	NN NN NN	DD    DD                          *
//					EEEE    	NN  NNNN	DD    DD                          *
//					EE     		NN   NNN	DD   DD                           *
//					EEEEEEE 	NN    NN	DDDDDD                            *
//*****************************************************************************