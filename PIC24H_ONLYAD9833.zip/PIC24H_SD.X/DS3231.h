#ifndef _DS3231_H
#define _DS3231_H

#include <stdint.h>

#define SECONDS (timeData.sec10s*10 + timeData.sec1s)
#define MINUTES (timeData.min10s*10 + timeData.min1s)
#define HOURS   (timeData.hrs10s*10 + timeData.hrs20s + timeData.hrs1s)
#define DAY   (timeData.day*10 + timeData.RESERVED3)
#define DATE   (timeData.dateH*10 + timeData.dateL + timeData.RESERVED4)
#define MONTH   (timeData.monthH*10 + timeData.monthL + timeData.RESERVED5)
#define YEAR   (timeData.yearH*10 + timeData.yearL)

typedef struct timeRegisters{
  union{
    uint8_t secReg;
    struct{
      uint8_t sec1s :4;
      uint8_t sec10s :3;
      uint8_t :1; //unused
    }; 
  };

  union{
    uint8_t minReg;
    struct{
      uint8_t min1s :4;
      uint8_t min10s :3;
      uint8_t :1; //unused
    }; 
  };

  union{
    uint8_t hrsReg;
    struct{
      uint8_t hrs1s :4;
      uint8_t hrs10s :1;
      uint8_t hrs20s :1;
      uint8_t :2; //unused
    }; 
  };
  
   union{
    uint8_t dayReg;
    struct{
  uint8_t day:3;
    uint8_t RESERVED3:5;
    };
   };
    union{
    uint8_t dateReg;
    struct{
    uint8_t dateL:4;
    uint8_t dateH:2;
    uint8_t RESERVED4:2;
    };
    };
     union{
    uint8_t monthReg;
    struct{
    uint8_t monthL:4;
    uint8_t monthH:1;
    uint8_t RESERVED5:3;
    };
     };
      union{
    uint8_t yearReg;
    struct{
    uint8_t yearL:4;
    uint8_t yearH:4;
    };
      };
  
}timeRegisters;

extern timeRegisters timeData;

#define DS3231_ADDRESS 0x68         ///< I2C address for DS3231
#define DS3231_TIME 0x00            ///< Time register
#define DS3231_ALARM1 0x07          ///< Alarm 1 register
#define DS3231_ALARM2 0x0B          ///< Alarm 2 register
#define DS3231_CONTROL 0x0E         ///< Control register
#define DS3231_STATUSREG 0x0F       ///< Status register
#define DS3231_TEMPERATUREREG 0x11  ///< Temperature register 

///////////////////////////
/* Function Declarations */
///////////////////////////

/*
    @Summary
        Updates the values inside the time struct

    @Description
        Reads the hour, minute, and second registers from the DS3231 and updates
        the corresponding fields in the structure

    @Preconditions
        Must have initialized I2C and DS3231 must have a valid time
    
    @Param
        None

    @Returns
        True on successful read of registers
*/

void DS3231_RefreshTime(void);


/*
     @Summary
        Formats a string as a timestamp

    @Description
        Fills in a string with the following format: "hh:mm:ss"

    @Preconditions
        Must have refreshed the time for it to be useful, preferably right before
    
    @Param
        str - string to be formatted

    @Returns
        None
*/

void Generate_Datestamp(char *str);
/* made to generate date info as str return
 */
void Generate_Timestamp(char *str);

/*
     @Summary
        Enables a global counter for milliseconds

    @Description
        A global variable (millis) will be updated constantly by the 1kHz clock from
        the DS3231.     
        Note: This is an interrupt service which will be updating the variable every millisecond

    @Preconditions
        Must have properly initialized the DS3231
    
    @Param
        None

    @Returns
        None
*/

void DS3231_Enable_INT1_millis(void);

#endif