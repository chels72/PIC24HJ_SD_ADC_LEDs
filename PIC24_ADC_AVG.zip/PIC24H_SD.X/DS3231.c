#include "DS3231.h"
#include "mcc_generated_files/i2c1.h"
#include <stdio.h>

#define SLAVE_I2C_GENERIC_DEVICE_TIMEOUT 100
#define SLAVE_I2C_GENERIC_RETRY_MAX 200

timeRegisters timeData;

/*Local Functions*/
bool DS3231_SendCommand(uint8_t reg, uint8_t command);
bool DS3231_Read(uint8_t reg, uint8_t *data, uint8_t nBytes);

void DS3231_RefreshTime(void)
{
    uint8_t data[3];
    if (DS3231_Read(DS3231_TIME, data, 3) == true)
    {
        timeData.secReg = data[0];
        timeData.minReg = data[1];
        timeData.hrsReg = data[2];
    }
    
};

void Generate_Timestamp(char *str)
{
    sprintf(str, "%02d:%02d:%02d", HOURS, MINUTES, SECONDS);
   
}

void DS3231_Enable_INT1_millis(void)
{
    //Set up interrupt (not yet enabled)
    
    //Set up an alarm for the next second, enable 1kHz sqw
    
    //Wait for seconds rollover (alarm), begin interrupt service
    
    //disable seconds alarm
    
}


/* Supporting Functions */

bool DS3231_SendCommand(uint8_t reg, uint8_t command)
{
    uint8_t data[2] = {reg, command};
    I2C1_MESSAGE_STATUS status = I2C1_MESSAGE_PENDING;
    uint8_t timeOut = 0;
    uint8_t slaveTimeOut = 0;

    while(status != I2C1_MESSAGE_FAIL)
    {
        I2C1_MasterWrite(data, 2, DS3231_ADDRESS, &status);

        while(status == I2C1_MESSAGE_PENDING)
        {
            //__delay_ms(1);
            //__delay_us(10);
            uint8_t i;
            for(i = 0; i < 50; i++);
            // timeout checking
            // check for max retry and skip this byte
            if (slaveTimeOut == SLAVE_I2C_GENERIC_DEVICE_TIMEOUT)
                break;
            else
                slaveTimeOut++;
        }
        if ((slaveTimeOut == SLAVE_I2C_GENERIC_DEVICE_TIMEOUT) ||
                (status == I2C1_MESSAGE_COMPLETE))
                break;

            // if status is  I2C1_MESSAGE_ADDRESS_NO_ACK,
            //               or I2C1_DATA_NO_ACK,
            // The device may be busy and needs more time for the last
            // write so we can retry writing the data, this is why we
            // use a while loop here

            // check for max retry and skip this byte
            if (timeOut == SLAVE_I2C_GENERIC_RETRY_MAX)
                break;
            else
                timeOut++;
    }

    if(status == I2C1_MESSAGE_COMPLETE)
        return true;
    else
        return false;

}

bool DS3231_Read(uint8_t reg, uint8_t *data, uint8_t nBytes)
{
    I2C1_MESSAGE_STATUS status = I2C1_MESSAGE_PENDING;
    uint16_t    retryTimeOut, slaveTimeOut;


    // Now it is possible that the slave device will be slow.
    // As a work around on these slaves, the application can
    // retry sending the transaction
    retryTimeOut = 0;
    slaveTimeOut = 0;

    while(status != I2C1_MESSAGE_FAIL)
    {
        // write one byte
        I2C1_MasterWrite(&reg, 1, DS3231_ADDRESS, &status);

        // wait for the message to be sent or status has changed.
        while(status == I2C1_MESSAGE_PENDING)
        {
            // add some delay here
            //__delay_ms(1);
            //__delay_us(100);
            uint8_t i;
            for(i = 0; i < 50; i++);
            // timeout checking
            // check for max retry and skip this byte
            if (slaveTimeOut == SLAVE_I2C_GENERIC_DEVICE_TIMEOUT)
            {
                return (false);
            }
            else
                slaveTimeOut++;
        }

        if (status == I2C1_MESSAGE_COMPLETE)
            break;

        // if status is  I2C1_MESSAGE_ADDRESS_NO_ACK,
        //               or I2C1_DATA_NO_ACK,
        // The device may be busy and needs more time for the last
        // write so we can retry writing the data, this is why we
        // use a while loop here

        // check for max retry and skip this byte
        if (retryTimeOut == SLAVE_I2C_GENERIC_RETRY_MAX)
            break;
        else
            retryTimeOut++;
    }

    if (status == I2C1_MESSAGE_COMPLETE)
    {

        // this portion will read the byte from the memory location.
        retryTimeOut = 0;
        slaveTimeOut = 0;

        while(status != I2C1_MESSAGE_FAIL)
        {
            //read
            I2C1_MasterRead(data, nBytes, DS3231_ADDRESS, &status);

            // wait for the message to be sent or status has changed.
            while(status == I2C1_MESSAGE_PENDING)
            {
                // add some delay here
                
                uint8_t i;
                for(i = 0; i < 50; i++);
                //__delay_ms(1);
                //__delay_us(10);
                // timeout checking
                // check for max retry and skip this byte
                if (slaveTimeOut == SLAVE_I2C_GENERIC_DEVICE_TIMEOUT)
                {
                    return false;
                }
                else
                    slaveTimeOut++;
            }

            if (status == I2C1_MESSAGE_COMPLETE)
                break;

            // if status is  I2C1_MESSAGE_ADDRESS_NO_ACK,
            //               or I2C1_DATA_NO_ACK,
            // The device may be busy and needs more time for the last
            // write so we can retry writing the data, this is why we
            // use a while loop here

            // check for max retry and skip this byte
            if (retryTimeOut == SLAVE_I2C_GENERIC_RETRY_MAX)
                break;
            else
                retryTimeOut++;
        }
    }

    // exit if the last transaction failed
    if (status == I2C1_MESSAGE_FAIL)
    {
        return(false);
    }                                                                                             

    return(true);
}